<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Mon premier thème WordPress</title>
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css">
<?php wp_head(); ?>
</head>
<body>

  <header>
    Ici notre header
  </header>
