<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Mon premier thème WordPress</title>
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css">
</head>
<body>

<h1>Bienvenue sur <?php bloginfo('name'); ?></h1>

<p><?php bloginfo('description'); ?></p>
<p>Chemin du thème : <?php bloginfo('template_url'); ?></p>
<p>Adresse email : <?php bloginfo('admin_email'); ?></p>

</body>
</html>
