<?php
/* Template Name: Gabarit A Propos */
?>


<?php
get_header();
?>

<section>
  <?php while ( have_posts() ) : the_post(); ?>

   <h1><?php the_title(); ?></h1>

   <div class="content">
       <?php the_content();?>
   </div>

   <?php endwhile; ?>
</section>
<section>
  <h2>Compétences</h2>
  <p>Ici les compétences</p>
</section>
<section>
  <h2>Expériences</h2>
  <p>Ici les expériences</p>
</section>


<?php
get_footer();
?>
