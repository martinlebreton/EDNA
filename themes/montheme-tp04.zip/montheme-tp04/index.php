<?php
get_header();
?>

<section>
  <h1>Bienvenue sur <?php bloginfo('name'); ?></h1>

  <p><?php bloginfo('description'); ?></p>
  <p>Chemin du thème : <?php bloginfo('template_url'); ?></p>
  <p>Adresse email : <?php bloginfo('admin_email'); ?></p>
</section>


<?php
get_footer();
?>
