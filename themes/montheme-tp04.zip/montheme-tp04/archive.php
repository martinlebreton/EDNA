<?php
get_header();
?>

<h1><?php single_cat_title(); ?></h1>
<?php if(category_description()){?>
    		<div>
    			 <?php echo category_description(); ?>
    		</div>
<?php }?>

<?php if (have_posts()) : ?>
  <?php while (have_posts()) : the_post(); ?>

    <!-- Début : Pour CHAQUE Référence (article), j'afficherai ça : -->
    <div class="ref">
        <h2><?php the_title(); ?></h2>
        <a href="<?php the_permalink(); ?>">lien vers la référence</a>
    </div>
    <!-- Fin -->

  <?php endwhile; ?>
<?php endif; ?>

<?php
get_footer();
?>
