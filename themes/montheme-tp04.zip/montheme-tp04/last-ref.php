<?php
// on construit les arguments de la requete
$args = array(
  'posts_type'     => 'post', // de type post
  'posts_per_page' => '3', // 3 posts seulement
  'orderby'        => 'date', // tri par date
  'order'					 => 'DESC', // tri ascendant
  'category_name'  => 'projets', // dans la categorie qui a exactement pour nom "projets"
);
// on execute la requete
$the_query = new WP_Query( $args );
?>


<?php
// si il y a un résultat et des posts :
if ( $the_query->have_posts() ) :
  ?>


  <?php
  // tant qu'il y a des posts correspondant à notre requête
  // debut de la boucle
      while ( $the_query->have_posts() ) : $the_query->the_post();
      ?>

        <div class="ref last-ref">
          <h2><?php the_title(); ?></h2>
          <p>image à la une</p>
        </div>

      <?php
      // fin de la boucle
      endwhile;
  ?>

  <?php
  wp_reset_postdata();
  // on sort de la boucle stoppe la requete, nous sommes prêt pour une nouvelle si nécessaire
  ?>

<?php else : ?>
  <p>pas de dernière référence</p>
<?php endif; ?>
