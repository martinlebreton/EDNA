<?php
get_header();
?>

<section>
  <h1 class="erreur-404">404</h1>
</section>



<?php
get_footer();
?>
