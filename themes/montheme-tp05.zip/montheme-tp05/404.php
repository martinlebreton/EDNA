<?php
get_header();
?>

<section>
  <h1 class="erreur-404">404</h1>
  <p>Retour à la <a href="<?php echo home_url(); ?>">page accueil</a></p>
</section>



<?php
get_footer();
?>
