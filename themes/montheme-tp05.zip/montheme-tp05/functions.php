<?php


/* On référence ici les menus */
register_nav_menus( array(
	'principal' => __( 'Navigation principale'),
	'social' => __( 'Menu des réseaux sociaux'),
) );

/* Image mise en avant*/
add_theme_support('post-thumbnails');


 ?>
