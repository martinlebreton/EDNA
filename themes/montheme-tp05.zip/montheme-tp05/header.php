<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Mon premier thème WordPress</title>
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

  <header>
    <div class="logo">
      <a href="<?php echo home_url(); ?>">
        <img
        src="<?php bloginfo('template_url'); ?>/assets/img/logo.svg"
        alt="logo <?php bloginfo('name'); ?>"
        height="126px"
        width="64px" />
      </a>
    </div>
    <div id="navigation">
      <?php
        wp_nav_menu( array(
        'theme_location' => 'principal',
        ) );
      ?>
    </div>
  </header>
