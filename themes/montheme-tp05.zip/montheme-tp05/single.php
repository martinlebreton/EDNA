<?php
get_header();
?>

<article>
  <?php while ( have_posts() ) : the_post(); ?>

  <h1 class="title"><?php the_title(); ?></h1>

  <p class="post-info">
  Posté le <?php the_date(); ?>
  dans <?php the_category(', '); ?>
  par <?php the_author(); ?>.
  </p>

  <div class="content">
  <?php the_content(); ?>
  </div>

  <?php endwhile; ?>

</article>



<?php
get_footer();
?>
