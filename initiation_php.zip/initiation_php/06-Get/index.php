<h1>Premier pas en PHP 06</h1>

<h2>Communication entre pages</h2>
<p>Ce <a href="page.php?name=Henry">lien</a> contient le prénom Henry</p>
<p>Ce <a href="page.php?name=Sylvie">lien</a> contient le prénom Sylvie</p>
<p>Ce <a href="page.php?name=Juliette&age=23">lien</a> contient le prénom Juliette et un age</p>
