<footer>
  Ici c'est le footer
<?php echo $variable; ?>
</footer>
